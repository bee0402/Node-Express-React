export interface IError{
    status: number;
    message: string;
}
import user from './routes/user';
import history from './routes/history';

export default { history, user };

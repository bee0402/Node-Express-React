declare module "*.png" {
    const value: string;
    export = value;
}

declare module '*.jpg'
declare module '*.gif'
declare module '*.less'
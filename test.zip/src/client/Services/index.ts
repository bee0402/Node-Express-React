import Post from './Post';
import Get from './Get';
import Delete from './Delete';
import Put from './Put';

export {
    Post,
    Get,
    Delete,
    Put,
}
